

print("\nCalculating how much a vehicle burns per kilometer\n")

k = float(input("How much $ does the car burn in Kilometers:"))
t = int(input("Kilometers Traveled:"))

calculate = k * t

print("Amount to be paid: {} $".format(calculate))