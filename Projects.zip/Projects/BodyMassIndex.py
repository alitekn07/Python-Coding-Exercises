

print("\nBody Mass Index\n")

h = float(input("Enter Height: "))
w = float(input("Enter Weight: "))

index = w / h ** 2

print("Body Mass Index {}".format(index))