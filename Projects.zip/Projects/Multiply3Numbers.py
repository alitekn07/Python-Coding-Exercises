
print("\nMultiply Three Numbers\n")

n1 = int(input("Enter first number: "))
n2 = int(input("Enter second number: "))
n3 = int(input("Enter third number: "))

multiply = n1 * n2 * n3

print("\nMultiply Of 3 Number: {}".format(multiply))
