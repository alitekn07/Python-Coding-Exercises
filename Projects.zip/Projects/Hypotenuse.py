

print("\nFinding the length of the hypotenuse\n")

a = float(input("Please enter the 1st perpendicular: "))
b = float(input("Please enter the 2st perpendicular: "))


c = (a ** 2 + b ** 2) ** 0.5


print("hypotenuse length: ",c)